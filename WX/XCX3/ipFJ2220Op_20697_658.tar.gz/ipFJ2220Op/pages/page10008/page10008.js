var app      = getApp();

var pageData = {
  data: {"picture1":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:112.5rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65917166e8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"6.68","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_894183913892","page_form":"","compId":"picture1"},"text2":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"\u5bb6\u88c5\u9632\u6c34\uff0c\u662f\u5bb6\u88c5\u4e2d\u6700\u91cd\u8981\u7684\u4e00\u9053\u5de5\u5e8f\uff0c\u6211\u4eec\u575a\u51b3\u4e00\u4e1d\u4e0d\u82df\u5bf9\u5f85\u6bcf\u4e00\u4ef6\u4f5c\u54c1\uff0c\u6bcf\u4e00\u9053\u5de5\u827a\u3001\u6bcf\u4e00\u4e2a\u5de5\u5e8f\uff0c\u6211\u4eec\u7686\u4e13\u6ce8\u7ec6\u8282\uff0c\u8ffd\u6c42\u6781\u81f4\uff0c\u7cbe\u76ca\u6c42\u7cbe\u529b\u7b51\u5b8c\u7f8e\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_32765288028","page_form":"","compId":"text2","markColor":"","mode":0},"picture3":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66e445bce7.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"9.58","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_418876424255","page_form":"","compId":"picture3"},"picture4":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:0rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca6718641f86.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"10.47","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_193864447463","page_form":"","compId":"picture4"},"picture5":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:0rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca6725830ac6.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"9.45","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_925544741279","page_form":"","compId":"picture5"},"picture6":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:35.15625rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca674288f5c9.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_958148333567","page_form":"","compId":"picture6"},"text7":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"\u603b\u7ed3\u591a\u5e74\u7684\u5de5\u5730\u5b9e\u64cd\u7ecf\u9a8c\uff0c\u6c72\u53d6\u5fb7\u827a\u5de5\u827a\u7cbe\u9ad3\uff0c\u575a\u5b88\u7528\u6c34\u7528\u7535\u957f\u5c45\u4e45\u5b89\u539f\u5219\uff0c\u5168\u9762\u4fdd\u969c\u5bb6\u5c45\u7528\u6c34\u5b89\u5168\u3001\u6301\u4e45\u3001\u8010\u7528\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_981164400864","page_form":"","compId":"text7","markColor":"","mode":0},"picture8":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:35.15625rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca673b36ee19.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_5766460535","page_form":"","compId":"picture8"},"text9":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"1\u3001\u57fa\u5c42\u5904\u7406 ","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_756888993478","page_form":"","compId":"text9","markColor":"","mode":0},"picture10":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:562.5rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca674f406056.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_532203828431","page_form":"","compId":"picture10"},"text11":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u4e00\u822c\u5148\u4ed4\u7ec6\u6e05\u626b\u57fa\u9762\u53bb\u9664\u6d6e\u5c18\uff0c\u5e76\u53bb\u9664\u6c34\u6ce5\u7ed3\u5757\u548c\u677e\u52a8\u57fa\u5c42\uff1b\u5bf9\u7ba1\u6839\u3001\u6392\u6c34\u5b54\u3001\u9634\u9633\u89d2\u3001\u5899\u9762\u6c34\u7535\u6539\u540e\u7559\u4e0b\u7684\u7a7a\u6d1e\u7b49\u90e8\u4f4d\u8fdb\u884c\u7279\u6b8a\u5904\u7406\uff0c\u9634\u9633\u89d2\u5904\u5e94\u62b9\u6210\u5706\u5f27\u5f62(\u6216V\u5b57\u578b)\uff1b\u4e0d\u5e73\u3001\u5f00\u88c2\u7684\u90e8\u5206\uff0c\u9700\u8981\u91cd\u65b0\u4fee\u590d\uff0c\u5e76\u627e\u5e73\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_705287343402","page_form":"","compId":"text11","markColor":"","mode":0},"text12":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"2\u3001\u5f00\u69fd\u5904\u505a\u9632\u6c34","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_105258954046","page_form":"","compId":"text12","markColor":"","mode":0},"picture13":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:398.4375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/thumb\/t_15544129115ca6756f7fa63.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.68","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_515862689423","page_form":"","compId":"picture13"},"text14":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u4e0d\u7ba1\u662f\u53a8\u623f\u8fd8\u662f\u5395\u6240\uff0c\u6c34\u7ba1\u5f00\u69fd\u5904\u5148\u505a\u4e00\u9053\u9632\u6c34\u518d\u5b89\u88c5\u6c34\u7ba1\u80fd\u6709\u6548\u907f\u514d\u6f0f\u6c34\u7684\u60c5\u51b5\u53d1\u751f\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_635028196676","page_form":"","compId":"text14","markColor":"","mode":0},"text15":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"3\u3001\u6c34\u7ba1\u3001\u5899\u89d2\u5012\u5f27\u5904\u7406","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_487883662136","page_form":"","compId":"text15","markColor":"","mode":0},"picture16":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:421.875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/thumb\/t_15544130135ca675d5e2b7b.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.58","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_57938291655","page_form":"","compId":"picture16"},"picture17":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:445.3125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca675f322ba8.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.53","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_576653190649","page_form":"","compId":"picture17"},"text18":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"\u6c34\u6ce5\u7802\u627e\u5e73\uff0c\u4fdd\u8bc1\u4e8c\u6b21\u6392\u6c34\u5730\u6f0f\u4e3a\u6700\u5e95\u5904\uff0c\u4fbf\u4e8e\u6392\u6c34\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_380995636687","page_form":"","compId":"text18","markColor":"","mode":0},"text19":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"4\u3001\u5f00\u59cb\u5237\u9632\u6c34\u6750\u6599","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_847909113167","page_form":"","compId":"text19","markColor":"","mode":0},"picture20":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:421.875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca676af4ecdf.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.66","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_245906783087","page_form":"","compId":"picture20"},"text21":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u4f7f\u7528\u6bdb\u5237\u5bf9\u57fa\u9762\u8fdb\u884c\u6d82\u5237\u5904\u7406\uff0c\u6d82\u5237\u5b8c\u7b2c\u4e00\u904d\u4e4b\u540e\uff0c\u95f4\u96941-3\u5c0f\u65f6\u8fdb\u884c\u7b2c\u4e8c\u904d\u7684\u6d82\u5237\u5de5\u4f5c\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_979356257443","page_form":"","compId":"text21","markColor":"","mode":0},"picture22":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca67f57c1fe8.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.58","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_927327440898","page_form":"","compId":"picture22"},"text23":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u9632\u6c34\u6750\u6599\u7684\u6d82\u5237\uff1a\u201c\u8584\u6d82\u591a\u5c42\u201d\uff0c\u4e5f\u5c31\u662f\u8bf4\u4e00\u6b21\u5747\u5300\u7684\u6d82\u62b9\u4e00\u5c42\uff0c\u5206\u591a\u6b21\u6d82\uff0c\u56e0\u4e3a\u8584\u6d82\u624d\u80fd\u5e72\u900f\uff0c\u9632\u6c34\u6750\u6599\u662f\u5e72\u900f\u540e\u624d\u53ef\u4ee5\u5f62\u6210\u4e00\u5c42\u4fdd\u62a4\u819c\u6765\u8fdb\u884c\u9632\u6c34\u7684\uff0c\u800c\u4e14\u6bcf\u6b21\u6d82\u62b9\u7684\u65b9\u5411\u4e5f\u8981\u8c03\u6574\uff0c\u4e00\u9053\u662f\u76f4\u6d82\uff0c\u53e6\u4e00\u9053\u5c31\u8981\u6a2a\u6d82\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_754007570504","page_form":"","compId":"text23","markColor":"","mode":0},"text24":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"5\u3001\u95ed\u6c34\u8bd5\u9a8c","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_555164541998","page_form":"","compId":"text24","markColor":"","mode":0},"picture25":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:515.625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca67fac17b42.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.52","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_102160234091","page_form":"","compId":"picture25"},"text26":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"\u7b2c\u4e00\u904d\u9632\u6c34\u540e48\u5c0f\u65f6\u95ed\u6c34\u8bd5\u9a8c\uff0c\u786e\u4fdd\u65e0\u6f0f\u6c34\uff01","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_711756461286","page_form":"","compId":"text26","markColor":"","mode":0},"text27":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"6\u3001\u95ed\u6c34\u8bd5\u9a8c\u901a\u8fc7\u540e\uff0c\u5f00\u59cb\u9676\u7c92\u56de\u586b","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_530045654438","page_form":"","compId":"text27","markColor":"","mode":0},"picture28":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca68008c2d26.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.36","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_991072324593","page_form":"","compId":"picture28"},"picture29":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca680174afef.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.31","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_954469933771","page_form":"","compId":"picture29"},"text30":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u536b\u751f\u95f4\u7b2c\u4e00\u904d\u9632\u6c34\u540e48\u5c0f\u65f6\u95ed\u6c34\u5b9e\u9a8c\u540e\u63a5\u7740\u9676\u7c92\u56de\u586b\u5de5\u827a\uff0c\u7136\u540e\u6c34\u6ce5\u7802\u6d46\u627e\u5e73\u540e\u518d\u5237\u4e00\u904d\u9632\u6c34\uff0c\u4e8c\u6b21\u9632\u6c34\u786e\u4fdd\u536b\u751f\u95f4\u4e0d\u4f1a\u6f0f\u6c34\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_303987927292","page_form":"","compId":"text30","markColor":"","mode":0},"picture31":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca68097a6f66.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_844637431268","page_form":"","compId":"picture31"},"text32":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:82.03125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"1\u3001\u5e03\u94a2\u7b4b\u3001\u627e\u5e73","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_594571019499","page_form":"","compId":"text32","markColor":"","mode":0},"picture33":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:515.625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca680fedad96.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.40","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_304703712664","page_form":"","compId":"picture33"},"picture34":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:515.625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca680fdd9dcc.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_247286470921","page_form":"","compId":"picture34"},"text35":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u56de\u586b\u540e\u7528\u6c34\u6ce5\u627e\u5e73\uff0c\u5982\u679c\u662f\u7528\u5750\u4fbf\u5668\u76f4\u63a5\u5168\u90e8\u627e\u5e73\uff0c\u7528\u8e72\u4fbf\u5668\u5c31\u5728\u4e0b\u6c34\u53e3\u7559\u4e2a\u51f9\u5751\uff0c\u653e\u8e72\u4fbf\u5668\u3002\u7b2c\u4e8c\u904d\u9632\u6c34\u5728\u88c5\u8e72\u4fbf\u5668\u524d\u5237\uff0c\u800c\u4e0d\u662f\u5728\u6309\u4e86\u8e72\u4fbf\u5668\u518d\u5237\uff0c\u90a3\u6837\u4f1a\u6709\u7f1d\u9699\u7684\u3002\u7b2c\u4e8c\u6b21\u9632\u6c34\u4e5f\u662f\u5237\u4e24\u904d\u3002\u9632\u6c34\u5e72\u4e86\u540e\u8fd8\u662f\u8981\u8fdb\u884c48\u5c0f\u65f6\u95ed\u6c34\u8bd5\u9a8c\uff0c\u7136\u540e\u786e\u8ba4\u6ca1\u6709\u6f0f\u6c34\uff0c\u518d\u8d34\u74f7\u7816\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_747135346588","page_form":"","compId":"text35","markColor":"","mode":0},"text36":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:32.8125rpx;font-weight:bold;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:46.875rpx;opacity:1;text-align:left;","content":"      \u9632\u6c34\u662f\u4e00\u4e2a\u91cd\u8981\u7684\u5de5\u7a0b\uff0c\u4e00\u5b9a\u8981\u4e25\u683c\u7684\u6309\u7167\u7a0b\u5e8f\u6765\uff0c\u4e0d\u53ef\u5c11\u4e00\u6b65\uff0c\u4e0d\u7136\u540e\uff0c\u540e\u671f\u5165\u4f4f\u540e\u51fa\u4e86\u95ee\u9898\u4f1a\u5f88\u7cdf\u5fc3\u3002\u5f88\u591a\u88c5\u4fee\u516c\u53f8\u4e3a\u4e86\u6210\u672c\u4f1a\u5728\u9632\u6c34\u4e0a\u5077\u5de5\u51cf\u6599\u3002\u5077\u5de5\u51cf\u6599\u6700\u660e\u663e\u7684\u51e0\u4e2a\u70b9\u5c31\u662f\uff1a1\u3001\u56de\u586b\u524d\u4e0d\u5237\u9632\u6c34\uff1b2\u3001\u56de\u586b\u524d\u9632\u6c34\u53ea\u6709\u82b1\u6d12\u7684\u5899\u8fd4\u9ad81800mm\uff0c\u5176\u4f59\u8fd4\u9ad8300mm\uff1b3\u3001\u6bcf\u6b21\u9632\u6c34\u53ea\u5237\u4e00\u904d\uff1b4\u3001\u56de\u586b\u540e\u4e0d\u505a\u9632\u6c34\u3002\u5927\u5bb6\u64e6\u4eae\u773c\u775b\uff0c\u5728\u81ea\u5df1\u5bb6\u505a\u9632\u6c34\u65f6\uff0c\u770b\u6709\u6ca1\u6709\u6309\u6b65\u9aa4\u6765\u505a\uff0c\u5982\u679c\u6309\u7167\u6807\u51c6\u6b65\u9aa4\uff0c\u4f60\u5bb6\u536b\u751f\u95f4\u9632\u6c34\u7ba150\u5e74\u6ca1\u6709\u95ee\u9898\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_704539697417","page_form":"","compId":"text36","markColor":"","mode":0},"breakline37":{"type":"breakline","style":"border-width:117.1875rpx;border-bottom-style:solid;margin-top:23.4375rpx;margin-left:0;margin-right:auto;width:750rpx;border-bottom-color:rgba(0, 0, 0, 0);","content":"<div><\/div>","customFeature":{"name":"\u5206\u5272\u7ebf","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_352435470232","page_form":"","compId":"breakline37"},"has_tabbar":0,"page_hidden":true,"page_form":"store_list","top_nav":{"navigationBarBackgroundColor":"#fff","navigationBarTextStyle":"black","navigationBarTitleText":"\u9632\u6c34\u5de5\u827a"},"dataId":""},
    need_login: false,
      bind_phone: false,
    page_router: 'page10008',
    page_form: 'none',
      dataId: '',
      list_compids_params: [],
      user_center_compids_params: [],
      goods_compids_params: [],
  prevPage:0,
      tostoreComps: [],
      carouselGroupidsParams: [],
      relobj_auto: [],
      bbsCompIds: [],
      dynamicVesselComps: [],
      communityComps: [],
      franchiseeComps: [],
      cityLocationComps: [],
      seckillOnLoadCompidParam: [],
      dynamicClassifyGroupidsParams: [],
      newClassifyGroupidsParams: [],
      videoListComps: [],
      videoProjectComps: [],
      newsComps: [],
      popupWindowComps: [],
        formVesselComps: [],
      searchComponentParam: [],
      topicComps: [],
      topicClassifyComps: [],
      topicSortComps: [],
      rowNumComps: [],
      sidebarComps: [],
      slidePanelComps: [],
      newCountComps: [],
      exchangeCouponComps: [],
      communityGroupComps: [],
      groupBuyStatusComps: [],
      groupBuyListComps: [],
      timelineComps: [],
      signInComps: [],
    returnToVersionFlag: true,
  requesting: false,
  requestNum: 1,
  modelChoose: [],
  modelChooseId: '',
  modelChooseName: [],
  onLoad: function (e) {
    if (e.statisticsType == 11) {
      delete e.statisticsType
      delete e.needStatistics
    }
    if (e.franchisee) {
      this.franchiseeId = e.franchisee;
      this.setData({
        franchiseeInfo: {
          id: e.franchisee,
          mode: e.fmode || ''
        }
      });
    }
    app.onPageLoad(e);
    app.isNeedRewardModal();
  },
  dataInitial: function () {
    app.pageDataInitial();
    if (this.page_router === 'userCenterComponentPage'){
      this.getAppECStoreConfig();
    }
  },
  onPageScroll: function(e) {
    app.onPageScroll(e);
  },
  onShareAppMessage: function (e) {
    if (e.from == 'button') {
      if (e.target.dataset && e.target.dataset.from == 'topicButton') {
        let franchiseeId = app.getPageFranchiseeId();
        let chainParam = franchiseeId ? '&franchisee=' + franchiseeId : '';
        return app.shareAppMessage({
          path: '/informationManagement/pages/communityDetail/communityDetail?detail=' + e.target.dataset.id + chainParam,
          desc: e.target.dataset.desc,
          success: function(addTime) {
            app.getIntegralLog(addTime);
            app.CountSpreadCount(e.target.dataset.id);
          }
        });
      }
    };
    return app.onPageShareAppMessage(e, app.getIntegralLog);
  },
  onShow: function () {
    app.onPageShow();
  },
  onHide: function () {
    app.onPageHide();
  },
  reachBottomFuc: [],
  onReachBottom: function () {
    app.onPageReachBottom( this.reachBottomFuc );
  },
  onUnload: function () {
    app.onPageUnload(this);
  },
  slidePanelStart: function (e) {
    app.slidePanelStart(e);
  },
  slidePanelEnd: function (e) {
    app.slidePanelEnd(e);
  },
  onPullDownRefresh : function(){
    app.onPagePullDownRefresh();
  },
  tapPrevewPictureHandler: function (e) {
    app.tapPrevewPictureHandler(e);
  },
  pageScrollFunc: function (e) {
    app.pageScrollFunc(e);
  },
  dynamicVesselScrollFunc: function (e) {
    app.dynamicVesselScrollFunc(e);
  },
  goodsScrollFunc: function (e) {
    app.goodsScrollFunc(e);
  },
  changeCount: function (e) {
    app.changeCount(e);
  },
  tapMapDetail: function (e) {
    app.tapMapDetail(e);
  },
  listVesselTurnToPage: function (e) {
    app.listVesselTurnToPage(e);
  },
  dynamicVesselTurnToPage: function (e) {
    app.dynamicVesselTurnToPage(e);
  },
  userCenterTurnToPage: function (e) {
    app.userCenterTurnToPage(e);
  },
  turnToGoodsDetail: function (e) {
    app.turnToGoodsDetail(e);
  },
  turnToSeckillDetail: function (e) {
    app.turnToSeckillDetail(e);
  },
  sortListFunc: function (e) {
    app.sortListFunc(e);
  },
  selectLocal: function (e) {
    app.selectLocal(e);
  },
  cancelCity: function (e) {
    app.cancelCity(e);
  },
  bindCityChange: function (e) {
    app.bindCityChange(e);
  },
  submitCity: function (e) {
    app.submitCity(e);
  },
  callPhone: function (e) {
    app.callPhone(e);
  },
  tapVideoPlayHandler: function(e){
    app.tapVideoPlayHandler(e);
  },
  tapToPluginHandler: function (e) {
    app.tapToPluginHandler(e);
  },
  tapRefreshListHandler: function (e) {
    app.tapRefreshListHandler(e);
  },
  turnToCommunityPage: function (e) {
    app.turnToCommunityPage(e);
  },
  tapToTransferPageHandler: function () {
    app.tapToTransferPageHandler();
  },
  showGoodsShoppingcart: function(e){
    app.showGoodsShoppingcart(e);
  },
  showAddShoppingcart: function (e) {
    app.showAddShoppingcart(e);
  },
  hideAddShoppingcart: function () {
    app.hideAddShoppingcart();
  },
  selectGoodsSubModel: function (e) {
    app.selectGoodsSubModel(e);
  },
  resetSelectCountPrice: function () {
    app.resetSelectCountPrice();
  },
  clickTostoreMinusButton: function (e) {
    app.clickTostoreMinusButton(e);
  },
  clickTostorePlusButton: function (e) {
    app.clickTostorePlusButton(e);
  },
  readyToPay: function () {
    app.readyToTostorePay();
  },
  getValidateTostore: function () {
    app.getValidateTostore();
  },
  goToShoppingCart: function () {
    app.goToShoppingCart();
  },
  stopPropagation: function () {
  },
  turnToSearchPage:function (e) {
    app.turnToSearchPage(e);
  },
  previewImage: function (e) {
    var dataset = e.currentTarget.dataset;
    app.previewImage({
      current : dataset.src,
      urls: dataset.imgarr || [dataset.src],
    });
  },
  suspensionTurnToPage: function (e) {
    app.suspensionTurnToPage(e);
  },
  keywordList:{},
  bindSearchTextChange: function (e) {
    this.keywordList[e.currentTarget.dataset.compid] = e.detail.value;
  },
  // 文字组件跳到地图
  textToMap: function(e) {
    app.textToMap(e);
  },
  tapDynamicClassifyFunc: function(e){
    app.tapDynamicClassifyFunc(e);
  },
  // 跳转到资讯详情
  turnToNewsDetail: function (e) {
    app.turnToNewsDetail(e)
  },
  //切换资讯分类
  getNewsCateList: function (e) {
    app.getNewsCateList(e);
  },
  //话题组件
  topicEleScrollFunc: function (e) {
    app.topicEleScrollFunc(e);
  },
  switchTopiclistOrderBy: function (e) {
    app.switchTopiclistOrderBy(e);
  },
  switchTopicCategory: function (e) {
    app.switchTopicCategory(e);
  },
  turnToTopicDetail: function (e) {
    app.turnToTopicDetail(e);
  },
  pageBackTopAct: function (e) {
    app.pageBackTopAct(e);
  },
  turnToTopicPublish: function (e) {
    app.turnToTopicPublish(e);
  },
  showTopicCommentBox: function (e) {
    app.showTopicCommentBox(e);
  },
  showTopicPhoneModal: function (e) {
    app.showTopicPhoneModal(e);
  },
  topicMakePhoneCall: function (e) {
    app.topicMakePhoneCall(e);
  },
  showTopicReplyComment: function (e) {
    app.showTopicReplyComment(e);
  },
  topicCommentReplyInput: function (e) {
    app.topicCommentReplyInput(e);
  },
  topicReplycommentSubmit: function (e) {
    app.topicReplycommentSubmit(e);
  },
  topicPerformLikeAct: function (e) {
    app.topicPerformLikeAct(e);
  },
  topicImgLoad: function (e) {
    app.topicImgLoad(e);
  },
  topicCommentReplyfocus:function (e) {
    app.topicCommentReplyfocus(e);
  },
  topicCommentReplyblur:function (e) {
    app.topicCommentReplyblur(e);
  },

  // 筛选组件 综合排序tab = 0
  sortByDefault: function (e) {
    app.sortByDefault(e);
  },
  // 筛选组件 按销量排序 tab = 1
  sortBySales: function (e) {
    app.sortBySales(e);
  },
  // 筛选组件 按价格排序 tab = 2
  sortByPrice: function (e) {
    app.sortByPrice(e);
  },
  // 筛选组件 按取货排序 tab = 3
  pickUpStyle: function (e) {
    app.pickUpStyle(e);
  },
  hideFilterPickUpBox: function (e){
    app.hideFilterPickUpBox(e);
  },
  selectPickUp: function(e){
    app.selectPickUp(e);
  },
  surePickBtn: function(e){
    app.surePickBtn(e);
  },
  resetPickBtn: function(e){
    app.resetPickBtn(e);
  },
  // 筛选组件 展示侧边筛选
  filterList: function(e){
    app.filterList(e);
  },
  // 筛选侧栏确定
  filterConfirm: function(e){
    app.filterConfirm(e);
  },
  // 动画结束回调函数
  animationEnd: function(e){
    app.animationEnd(e);
  },
  //排号
  showTakeNumberWindow: function(e){
    app.showTakeNumberWindow(e);
  },
  hideTakeNumberWindow: function(e){
    app.hideTakeNumberWindow(e);
  },
  goToPreviewRowNumberOrder: function(e){
    app.goToPreviewRowNumberOrder(e);
  },
  selectRowNumberType: function(e){
    app.selectRowNumberType(e);
  },
  sureTakeNumber: function(e){
    app.sureTakeNumber(e);
  },
  goToCheckRowNunberDetail: function(e){
    app.goToCheckRowNunberDetail(e);
  },
  cancelCheckRowNunber: function(e){
    app.cancelCheckRowNunber(e);
  },
  rowNumberRefresh: function(e){
    app.rowNumberRefresh(e);
  },
  showCancelWindow: function (e) {
    app.showCancelWindow(e)
  },
  hideCancelWindow: function (e) {
    app.hideCancelWindow(e)
  },
  tapEventCommonHandler: function(e){
    app.tapEventCommonHandler(e);
  },
  getCarouselData: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app._initialCarouselData(this, compid );
  },
  getNewsList: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app.getNewsList({ compid: compid });
  },
  getCommunityList: function (e) {
    let compid = e.currentTarget.dataset.compid;
    app.initialCommunityList(compid);
  },
  getexchangeCoupon: function(e) {
    app.getexchangeCoupon(e);
  },
  turnToexchangeCouponDetail: function (e) {
    app.turnToexchangeCouponDetail(e);
  },
  exchangeCouponScrollFunc: function (e) {
    app.exchangeCouponScrollFunc(e);
  },
  vipCardTurnToPage: function (e) {
    app.vipCardTurnToPage(e);
  },
  showQRRemark: function (e) {
    app.showQRRemark(e);
  },
  tapDynamicShowAllClassify: function (e) {
    app.tapDynamicShowAllClassify(e);
  },
  dynamicSubClassifyAreaScrollEvent: function (e) {
    app.dynamicSubClassifyAreaScrollEvent(e);
  },
  slidePanelScrollEvent: function (e) {
    app.slidePanelScrollEvent(e);
  },
  unfoldSus: function(e) {
    let compId = e.currentTarget.dataset.compid;
    let tapType = e.currentTarget.dataset.taptype;
    app.newSuspension_unfoldSus(compId,tapType);
  },
  newCountTapEvent: function (e) {
    app.newCountTapEvent(e);
  },
  chengeCommunityGroup(e) {
    app.chengeCommunityGroup(e);
  },
  toCommunityGroup(e) {
    app.toCommunityGroup(e);
  },
  communityGroupScrollFunc(e) {
    app.communityGroupScrollFunc(e);
  },
  getAppECStoreConfig: function () {
    app.getAppECStoreConfig((res) => {
      this.setData({
        storeStyle: res.color_config
      })
    });
  },

  };
Page(pageData);
