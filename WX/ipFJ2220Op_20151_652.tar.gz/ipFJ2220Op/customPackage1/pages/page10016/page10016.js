var app      = getApp();

var pageData = {
  data: {"picture1":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:105.46875rpx;margin-left:auto;margin-right:auto;margin-top:0rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8dafb3e19e.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"6.20","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_6041115750","page_form":"","compId":"picture1"},"text2":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u5bb6\u7684\u672c\u8d28\uff0c\u662f\u5185\u5fc3\u7684\u5f52\u5bbf\uff0c\u65e0\u8bba\u65f6\u4ee3\u5982\u4f55\u53d8\u8fc1\uff0c\u65e0\u8bba\u65f6\u5c1a\u5f15\u9886\u7740\u600e\u6837\u7684\u6f6e\u6d41\uff0c\u5bf9\u4e8e\u5bb6\uff0c\u8ba9\u4eba\u6052\u4e45\u7737\u604b\u548c\u65e0\u9650\u56de\u5473\uff0c\u4e00\u5b9a\u662f\u5fc3\u4e2d\u6700\u521d\u7684\u90a3\u4e00\u7247\u98ce\u666f\uff0c\u81ea\u7136\u7b80\u5355\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_503139301611","page_form":"","compId":"text2","markColor":"","mode":0},"picture3":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:58.59375rpx;width:187.5rpx;margin-left:0;margin-right:auto;margin-top:46.875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8b2a6662fd.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"2.82","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_111294342779","page_form":"","compId":"picture3"},"picture4":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:480.46875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8da3017a28.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_902377655883","page_form":"","compId":"picture4"},"picture5":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:525rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8dafd38cfe.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_3477745126","page_form":"","compId":"picture5"},"text6":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u6ca1\u6709\u7e41\u590d\u7684\u8bbe\u8ba1\uff0c\u901a\u8fc7\u539f\u6728\u7684\u914d\u8272\u6765\u8425\u9020\u51fa\u65e5\u5f0f\u7684\u7b80\u5355\u8212\u9002\u611f\u3002\u642d\u914d\u6728\u8d28\u8336\u51e0\u3001\u7535\u89c6\u67dc\u3001\u5e03\u827a\u6c99\u53d1\u7ec4\u5408\uff0c\u8ba9\u4eba\u7684\u89c6\u89c9\u6548\u679c\u5f88\u7b80\u7ea6\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_590512877148","page_form":"","compId":"text6","markColor":"","mode":0},"picture7":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:58.59375rpx;width:187.5rpx;margin-left:0;margin-right:auto;margin-top:46.875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8b2a73a45c.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"2.82","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_670184171032","page_form":"","compId":"picture7"},"picture8":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:539.0625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8dafe24f06.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_641619808600","page_form":"","compId":"picture8"},"text9":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u540a\u67dc\u548c\u4e0b\u9762\u6a71\u67dc\u7edf\u4e00\u539f\u6728\u98ce\uff0c\u642d\u914d\u534f\u8c03\uff0c\u5899\u9762\u94fa\u8d34\u6d45\u8272\u5899\u7816\uff0c\u6728\u8272\u7684\u6a71\u67dc\u642d\u914d\u767d\u8272\u53f0\u9762\uff0c\u7ed9\u4eba\u8f7b\u677e\u7684\u611f\u89c9\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_178357974846","page_form":"","compId":"text9","markColor":"","mode":0},"picture10":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:58.59375rpx;width:187.5rpx;margin-left:0;margin-right:auto;margin-top:46.875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8b2a32bbb4.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"2.82","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_882045555925","page_form":"","compId":"picture10"},"picture11":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:815.625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8db0395ff1.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.84","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_235608808794","page_form":"","compId":"picture11"},"text12":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u539f\u6728\u7684\u9910\u684c\u642d\u914d\u539f\u6728\u7684\u9910\u8fb9\u67dc\uff0c\u4e0d\u4ec5\u6709\u989c\u503c\uff0c\u5b9e\u7528\u6027\u4e5f\u80fd\u8ddf\u4e0a\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_158338899298","page_form":"","compId":"text12","markColor":"","mode":0},"picture13":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:58.59375rpx;width:187.5rpx;margin-left:0;margin-right:auto;margin-top:46.875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8b2ab2aacf.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"2.82","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_256198922781","page_form":"","compId":"picture13"},"picture14":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:496.875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8dafc56fde.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_68568643450","page_form":"","compId":"picture14"},"text15":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u539f\u6728\u5e26\u6765\u7684\u6e29\u6da6\u8d28\u611f\uff0c\u4f7f\u6574\u4e2a\u7a7a\u95f4\u6e29\u6696\u8212\u9002\u3002\u5348\u540e\u6d12\u8fdb\u6765\u7684\u4e00\u7c73\u9633\u5149\uff0c\u8ba9\u5367\u5ba4\u7684\u6c1b\u56f4\u66f4\u52a0\u6e29\u67d4\u606c\u6de1\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_644087786308","page_form":"","compId":"text15","markColor":"","mode":0},"picture16":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:618.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8db0291a6f.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.80","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_61773863969","page_form":"","compId":"picture16"},"text17":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u9633\u53f0\u4e0e\u5367\u5ba4\u8fde\u901a\uff0c\u7a7a\u95f4\u5bbd\u655e\u7684\u540c\u65f6\u5927\u5927\u589e\u52a0\u4e86\u91c7\u5149\u3002\u9633\u53f0\u7684\u4e00\u89d2\u8fd8\u8bbe\u7f6e\u4e86\u539f\u6728\u8d28\u611f\u7684\u4e66\u684c\uff0c\u6c90\u6d74\u5728\u9633\u5149\u4e0b\u7684\u751f\u6d3b\uff0c\u6e29\u6696\u53c8\u7f8e\u597d\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_848202043244","page_form":"","compId":"text17","markColor":"","mode":0},"picture18":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:822.65625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8db018d363.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.80","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_631694133985","page_form":"","compId":"picture18"},"text19":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u5367\u5ba4\u5c06\u65e5\u5f0f\u7b80\u7ea6\u539f\u6728\u98ce\u683c\u53d1\u6325\u7684\u6dcb\u6f13\u5c3d\u81f4\uff0c\u867d\u7136\u7b80\u5355\uff0c\u6696\u548c\u7684\u706f\u5149\u5374\u80fd\u8ba9\u4eba\u653e\u677e\u5fc3\u60c5\uff0c\u4e00\u4e1d\u4e1d\u7985\u610f\u6c81\u5165\u5fc3\u6249\u8d28\u6734\u6e05\u96c5\uff0c\u611f\u53d7\u5b83\u81ea\u7136\u4e0e\u7b80\u7ea6\u4eba\u751f\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_902365043563","page_form":"","compId":"text19","markColor":"","mode":0},"picture20":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:869.53125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8daff80420.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.80","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_548418616328","page_form":"","compId":"picture20"},"text21":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u9633\u53f0\u7684\u91c7\u5149\u81ea\u7136\u662f\u6781\u597d\u7684\uff0c\u653e\u4e00\u7ec4\u684c\u6905\u5c31\u53d8\u6210\u4e86\u5de5\u4f5c\u5730\uff0c\u53e6\u4e00\u4fa7\u517b\u4e9b\u82b1\u8349\uff0c\u81ea\u5728\u7684\u6070\u5230\u597d\u5904\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_134138141385","page_form":"","compId":"text21","markColor":"","mode":0},"picture22":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:58.59375rpx;width:187.5rpx;margin-left:0;margin-right:auto;margin-top:46.875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8b2a8e9890.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"2.82","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_222282718322","page_form":"","compId":"picture22"},"picture23":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:855.46875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca8db0089eea.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.80","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_365816149437","page_form":"","compId":"picture23"},"text24":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"      \u536b\u751f\u95f4\u5730\u9762\u94fa\u8bbe\u6df1\u8272\u5730\u7816\uff0c\u539f\u6728\u8272\u7684\u67dc\u4f53\uff0c\u642d\u914d\u7c73\u767d\u8272\u6d01\u5177\uff0c\u81ea\u7136\u5e72\u51c0\uff0c\u73bb\u7483\u79fb\u95e8\u5c3d\u91cf\u505a\u5230\u7a7a\u95f4\u7684\u5e72\u6e7f\u5206\u533a\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_800957042859","page_form":"","compId":"text24","markColor":"","mode":0},"breakline25":{"type":"breakline","style":"border-width:117.1875rpx;border-bottom-style:solid;margin-top:23.4375rpx;margin-left:0;margin-right:auto;width:750rpx;border-bottom-color:rgba(0, 0, 0, 0);","content":"<div><\/div>","customFeature":{"name":"\u5206\u5272\u7ebf","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_406702634268","page_form":"","compId":"breakline25"},"has_tabbar":0,"page_hidden":true,"page_form":"store_list","top_nav":{"navigationBarBackgroundColor":"#fff","navigationBarTextStyle":"black","navigationBarTitleText":"\u65e5\u5f0f\u539f\u6728\u98ce"},"dataId":""},
    need_login: false,
      bind_phone: false,
    page_router: 'page10016',
    page_form: 'none',
      dataId: '',
      list_compids_params: [],
      user_center_compids_params: [],
      goods_compids_params: [],
  prevPage:0,
      tostoreComps: [],
      carouselGroupidsParams: [],
      relobj_auto: [],
      bbsCompIds: [],
      dynamicVesselComps: [],
      communityComps: [],
      franchiseeComps: [],
      cityLocationComps: [],
      seckillOnLoadCompidParam: [],
      dynamicClassifyGroupidsParams: [],
      newClassifyGroupidsParams: [],
      videoListComps: [],
      videoProjectComps: [],
      newsComps: [],
      popupWindowComps: [],
        formVesselComps: [],
      searchComponentParam: [],
      topicComps: [],
      topicClassifyComps: [],
      topicSortComps: [],
      rowNumComps: [],
      sidebarComps: [],
      slidePanelComps: [],
      newCountComps: [],
      exchangeCouponComps: [],
      communityGroupComps: [],
      groupBuyStatusComps: [],
      groupBuyListComps: [],
      timelineComps: [],
      signInComps: [],
    returnToVersionFlag: true,
  requesting: false,
  requestNum: 1,
  modelChoose: [],
  modelChooseId: '',
  modelChooseName: [],
  onLoad: function (e) {
    if (e.statisticsType == 11) {
      delete e.statisticsType
      delete e.needStatistics
    }
    if (e.franchisee) {
      this.franchiseeId = e.franchisee;
      this.setData({
        franchiseeInfo: {
          id: e.franchisee,
          mode: e.fmode || ''
        }
      });
    }
    app.onPageLoad(e);
    app.isNeedRewardModal();
  },
  dataInitial: function () {
    app.pageDataInitial();
    if (this.page_router === 'userCenterComponentPage'){
      this.getAppECStoreConfig();
    }
  },
  onPageScroll: function(e) {
    app.onPageScroll(e);
  },
  onShareAppMessage: function (e) {
    if (e.from == 'button') {
      if (e.target.dataset && e.target.dataset.from == 'topicButton') {
        let franchiseeId = app.getPageFranchiseeId();
        let chainParam = franchiseeId ? '&franchisee=' + franchiseeId : '';
        return app.shareAppMessage({
          path: '/informationManagement/pages/communityDetail/communityDetail?detail=' + e.target.dataset.id + chainParam,
          desc: e.target.dataset.desc,
          success: function(addTime) {
            app.getIntegralLog(addTime);
            app.CountSpreadCount(e.target.dataset.id);
          }
        });
      }
    };
    return app.onPageShareAppMessage(e, app.getIntegralLog);
  },
  onShow: function () {
    app.onPageShow();
  },
  onHide: function () {
    app.onPageHide();
  },
  reachBottomFuc: [],
  onReachBottom: function () {
    app.onPageReachBottom( this.reachBottomFuc );
  },
  onUnload: function () {
    app.onPageUnload(this);
  },
  slidePanelStart: function (e) {
    app.slidePanelStart(e);
  },
  slidePanelEnd: function (e) {
    app.slidePanelEnd(e);
  },
  onPullDownRefresh : function(){
    app.onPagePullDownRefresh();
  },
  tapPrevewPictureHandler: function (e) {
    app.tapPrevewPictureHandler(e);
  },
  pageScrollFunc: function (e) {
    app.pageScrollFunc(e);
  },
  dynamicVesselScrollFunc: function (e) {
    app.dynamicVesselScrollFunc(e);
  },
  goodsScrollFunc: function (e) {
    app.goodsScrollFunc(e);
  },
  changeCount: function (e) {
    app.changeCount(e);
  },
  tapMapDetail: function (e) {
    app.tapMapDetail(e);
  },
  listVesselTurnToPage: function (e) {
    app.listVesselTurnToPage(e);
  },
  dynamicVesselTurnToPage: function (e) {
    app.dynamicVesselTurnToPage(e);
  },
  userCenterTurnToPage: function (e) {
    app.userCenterTurnToPage(e);
  },
  turnToGoodsDetail: function (e) {
    app.turnToGoodsDetail(e);
  },
  turnToSeckillDetail: function (e) {
    app.turnToSeckillDetail(e);
  },
  sortListFunc: function (e) {
    app.sortListFunc(e);
  },
  selectLocal: function (e) {
    app.selectLocal(e);
  },
  cancelCity: function (e) {
    app.cancelCity(e);
  },
  bindCityChange: function (e) {
    app.bindCityChange(e);
  },
  submitCity: function (e) {
    app.submitCity(e);
  },
  callPhone: function (e) {
    app.callPhone(e);
  },
  tapVideoPlayHandler: function(e){
    app.tapVideoPlayHandler(e);
  },
  tapToPluginHandler: function (e) {
    app.tapToPluginHandler(e);
  },
  tapRefreshListHandler: function (e) {
    app.tapRefreshListHandler(e);
  },
  turnToCommunityPage: function (e) {
    app.turnToCommunityPage(e);
  },
  tapToTransferPageHandler: function () {
    app.tapToTransferPageHandler();
  },
  showGoodsShoppingcart: function(e){
    app.showGoodsShoppingcart(e);
  },
  showAddShoppingcart: function (e) {
    app.showAddShoppingcart(e);
  },
  hideAddShoppingcart: function () {
    app.hideAddShoppingcart();
  },
  selectGoodsSubModel: function (e) {
    app.selectGoodsSubModel(e);
  },
  resetSelectCountPrice: function () {
    app.resetSelectCountPrice();
  },
  clickTostoreMinusButton: function (e) {
    app.clickTostoreMinusButton(e);
  },
  clickTostorePlusButton: function (e) {
    app.clickTostorePlusButton(e);
  },
  readyToPay: function () {
    app.readyToTostorePay();
  },
  getValidateTostore: function () {
    app.getValidateTostore();
  },
  goToShoppingCart: function () {
    app.goToShoppingCart();
  },
  stopPropagation: function () {
  },
  turnToSearchPage:function (e) {
    app.turnToSearchPage(e);
  },
  previewImage: function (e) {
    var dataset = e.currentTarget.dataset;
    app.previewImage({
      current : dataset.src,
      urls: dataset.imgarr || [dataset.src],
    });
  },
  suspensionTurnToPage: function (e) {
    app.suspensionTurnToPage(e);
  },
  keywordList:{},
  bindSearchTextChange: function (e) {
    this.keywordList[e.currentTarget.dataset.compid] = e.detail.value;
  },
  // 文字组件跳到地图
  textToMap: function(e) {
    app.textToMap(e);
  },
  tapDynamicClassifyFunc: function(e){
    app.tapDynamicClassifyFunc(e);
  },
  // 跳转到资讯详情
  turnToNewsDetail: function (e) {
    app.turnToNewsDetail(e)
  },
  //切换资讯分类
  getNewsCateList: function (e) {
    app.getNewsCateList(e);
  },
  //话题组件
  topicEleScrollFunc: function (e) {
    app.topicEleScrollFunc(e);
  },
  switchTopiclistOrderBy: function (e) {
    app.switchTopiclistOrderBy(e);
  },
  switchTopicCategory: function (e) {
    app.switchTopicCategory(e);
  },
  turnToTopicDetail: function (e) {
    app.turnToTopicDetail(e);
  },
  pageBackTopAct: function (e) {
    app.pageBackTopAct(e);
  },
  turnToTopicPublish: function (e) {
    app.turnToTopicPublish(e);
  },
  showTopicCommentBox: function (e) {
    app.showTopicCommentBox(e);
  },
  showTopicPhoneModal: function (e) {
    app.showTopicPhoneModal(e);
  },
  topicMakePhoneCall: function (e) {
    app.topicMakePhoneCall(e);
  },
  showTopicReplyComment: function (e) {
    app.showTopicReplyComment(e);
  },
  topicCommentReplyInput: function (e) {
    app.topicCommentReplyInput(e);
  },
  topicReplycommentSubmit: function (e) {
    app.topicReplycommentSubmit(e);
  },
  topicPerformLikeAct: function (e) {
    app.topicPerformLikeAct(e);
  },
  topicImgLoad: function (e) {
    app.topicImgLoad(e);
  },
  topicCommentReplyfocus:function (e) {
    app.topicCommentReplyfocus(e);
  },
  topicCommentReplyblur:function (e) {
    app.topicCommentReplyblur(e);
  },

  // 筛选组件 综合排序tab = 0
  sortByDefault: function (e) {
    app.sortByDefault(e);
  },
  // 筛选组件 按销量排序 tab = 1
  sortBySales: function (e) {
    app.sortBySales(e);
  },
  // 筛选组件 按价格排序 tab = 2
  sortByPrice: function (e) {
    app.sortByPrice(e);
  },
  // 筛选组件 按取货排序 tab = 3
  pickUpStyle: function (e) {
    app.pickUpStyle(e);
  },
  hideFilterPickUpBox: function (e){
    app.hideFilterPickUpBox(e);
  },
  selectPickUp: function(e){
    app.selectPickUp(e);
  },
  surePickBtn: function(e){
    app.surePickBtn(e);
  },
  resetPickBtn: function(e){
    app.resetPickBtn(e);
  },
  // 筛选组件 展示侧边筛选
  filterList: function(e){
    app.filterList(e);
  },
  // 筛选侧栏确定
  filterConfirm: function(e){
    app.filterConfirm(e);
  },
  // 动画结束回调函数
  animationEnd: function(e){
    app.animationEnd(e);
  },
  //排号
  showTakeNumberWindow: function(e){
    app.showTakeNumberWindow(e);
  },
  hideTakeNumberWindow: function(e){
    app.hideTakeNumberWindow(e);
  },
  goToPreviewRowNumberOrder: function(e){
    app.goToPreviewRowNumberOrder(e);
  },
  selectRowNumberType: function(e){
    app.selectRowNumberType(e);
  },
  sureTakeNumber: function(e){
    app.sureTakeNumber(e);
  },
  goToCheckRowNunberDetail: function(e){
    app.goToCheckRowNunberDetail(e);
  },
  cancelCheckRowNunber: function(e){
    app.cancelCheckRowNunber(e);
  },
  rowNumberRefresh: function(e){
    app.rowNumberRefresh(e);
  },
  showCancelWindow: function (e) {
    app.showCancelWindow(e)
  },
  hideCancelWindow: function (e) {
    app.hideCancelWindow(e)
  },
  tapEventCommonHandler: function(e){
    app.tapEventCommonHandler(e);
  },
  getCarouselData: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app._initialCarouselData(this, compid );
  },
  getNewsList: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app.getNewsList({ compid: compid });
  },
  getCommunityList: function (e) {
    let compid = e.currentTarget.dataset.compid;
    app.initialCommunityList(compid);
  },
  getexchangeCoupon: function(e) {
    app.getexchangeCoupon(e);
  },
  turnToexchangeCouponDetail: function (e) {
    app.turnToexchangeCouponDetail(e);
  },
  exchangeCouponScrollFunc: function (e) {
    app.exchangeCouponScrollFunc(e);
  },
  vipCardTurnToPage: function (e) {
    app.vipCardTurnToPage(e);
  },
  showQRRemark: function (e) {
    app.showQRRemark(e);
  },
  tapDynamicShowAllClassify: function (e) {
    app.tapDynamicShowAllClassify(e);
  },
  dynamicSubClassifyAreaScrollEvent: function (e) {
    app.dynamicSubClassifyAreaScrollEvent(e);
  },
  slidePanelScrollEvent: function (e) {
    app.slidePanelScrollEvent(e);
  },
  unfoldSus: function(e) {
    let compId = e.currentTarget.dataset.compid;
    let tapType = e.currentTarget.dataset.taptype;
    app.newSuspension_unfoldSus(compId,tapType);
  },
  newCountTapEvent: function (e) {
    app.newCountTapEvent(e);
  },
  chengeCommunityGroup(e) {
    app.chengeCommunityGroup(e);
  },
  toCommunityGroup(e) {
    app.toCommunityGroup(e);
  },
  communityGroupScrollFunc(e) {
    app.communityGroupScrollFunc(e);
  },
  getAppECStoreConfig: function () {
    app.getAppECStoreConfig((res) => {
      this.setData({
        storeStyle: res.color_config
      })
    });
  },

  };
Page(pageData);
