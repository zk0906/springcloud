
var app = getApp()
var util = require('../../utils/util.js')
var WxParse = require('../../components/wxParse/wxParse.js');
//var countDown = require('../../components/countDown/countDown.js')

Page({
  data: {
    goodsId: '',
    goodsInfo: {},
    modelStrs: {},
    selectModelInfo: {
      models: [],
      stock: '',
      price: '',
      buyCount: 1,
      groupBuyCount: 1,
      groupNum: '',
      groupPrice: '',
      groupLeaderPrice: ''
    },
    commentNums: [],
    commentExample: '',
    defaultPhoto: '',
    allStock: '',
    addToShoppingCartHidden: true,
    addToGroupBuyCart: true,
    ifOpenNewGroup: true,
    ifAddToShoppingCart: true,
    isParticipate: false,
    priceDiscountStr: '',
    ifAllGroup: true,
    clock: [],
  },
  time : '',
  onLoad: function (options) {
    var goodsId = options.detail || '',
      contact = options.contact || '',
      franchiseeId = options.franchisee || '',
      cartGoodsNum = options.cart_num || 0,
      userToken = options.user_token || '',
      defaultPhoto = app.getDefaultPhoto();

    this.setData({
      goodsId: goodsId,
      contact: contact,
      defaultPhoto: defaultPhoto,
      franchiseeId: franchiseeId,
      cartGoodsNum: cartGoodsNum
    })
    this.dataInitial();
    //推广存储user_token
    if(userToken){
      app.globalData.PromotionUserToken = userToken;
    }
  },
  onUnload:function(){
    !!this.time ? this.time.clear(): '';
  },
  dataInitial: function () {
    var that = this;
    app.sendRequest({
      url: '/index.php?r=AppShop/getGoods',
      data: {
        data_id: this.data.goodsId,
        sub_shop_app_id: this.data.franchiseeId
      },
      success: function (res) {
        that.modifyGoodsDetail(res);
        if(that.data.goodsInfo.group_buy_team_list && that.data.goodsInfo.group_buy_team_list.length){     // 存在拼团列表时进行
          //倒计时的调用
          that.parseArr(that.data.goodsInfo.group_buy_team_list)
          that.time = that.countDown();
        }
      }
    })
  },
  onShareAppMessage: function () {
    var that = this,
        goodsId = this.data.goodsId,
        contact = this.data.contact,
        franchiseeId = this.data.franchiseeId,
        urlPromotion = app.globalData.PromotionUserToken ? '&user_token=' + app.globalData.PromotionUserToken : '',
        url = '/pages/groupGoodsDetail/groupGoodsDetail?detail=' + goodsId + '&contact=' + contact + (franchiseeId ? '&franchisee=' + franchiseeId : '') + (app.globalData.pageShareKey ? ('&pageShareKey=' + app.globalData.pageShareKey) : '') + urlPromotion,
        nickname = app.getUserInfo('nickname'),
        title = (nickname ? nickname + ' 喊你' : '') + '拼单啦~ ' + this.data.goodsInfo.group_buy_info.group_buy_min_price + '元拼' + this.data.goodsInfo.title + '，火爆抢购中......';

    return app.shareAppMessage({
      title: title,
      path: url,
      imageUrl: 'https://cdn.jisuapp.cn/zhichi_frontend/static/webapp/images/group_goods_share.jpeg',
      success: function (addTime) {
        app.showToast({ title: '转发成功', duration: 500 });
        // 转发获取积分
        app.sendRequest({
          hideLoading: true,
          url: '/index.php?r=appShop/getIntegralLog',
          data: { add_time: addTime },
          success: function (res) {
            if (res.status == 0) {
              res.data && that.setData({
                'rewardPointObj': {
                  showModal: true,
                  count: res.data,
                  callback: ''
                }
              });
            }
          }
        })
      }
    });
  },
  showQRCodeComponent: function () {
    let that = this;
    let goodsInfo = this.data.goodsInfo;
    let animation = wx.createAnimation({
      timingFunction: "ease",
      duration: 400,
    })
    app.sendRequest({
      url: '/index.php?r=AppDistribution/DistributionShareQRCode',
      data: {
        obj_id: that.data.goodsId,
        type: 6,
        text: goodsInfo.title,
        price: (goodsInfo.highPrice > goodsInfo.lowPrice && goodsInfo.lowPrice != 0 ? (goodsInfo.lowPrice + ' ~ ' + goodsInfo.highPrice) : goodsInfo.price),
        goods_img: goodsInfo.img_urls ? goodsInfo.img_urls[0] : goodsInfo.cover,
        sub_shop_id: that.data.franchiseeId,
        p_id: app.globalData.p_id || ''
      },
      success: function (res) {
        animation.bottom("0").step();
        that.setData({
          "pageQRCodeData.shareDialogShow": 0,
          "pageQRCodeData.shareMenuShow": true,
          "pageQRCodeData.goodsInfo": res.data,
          "pageQRCodeData.animation": animation.export()
        })
      }
    })
  },
  goToMyOrder: function () {
    var franchiseeId = this.data.franchiseeId,
      pagePath = '/eCommerce/pages/myOrder/myOrder' + (franchiseeId ? '?franchisee=' + franchiseeId : '');
    app.turnToPage(pagePath, true);
  },
  goToShoppingCart: function () {
    var franchiseeId = this.data.franchiseeId,
      pagePath = '/eCommerce/pages/shoppingCart/shoppingCart' + (franchiseeId ? '?franchisee=' + franchiseeId : '');
    app.turnToPage(pagePath, true);
  },
  goToHomepage: function () {
    var router = app.getHomepageRouter();
    app.turnToPage('/pages/' + router + '/' + router, true);
  },
  goToCommentPage: function () {
    var franchiseeId = this.data.franchiseeId,
      pagePath = '/eCommerce/pages/goodsComment/goodsComment?detail=' + this.data.goodsId + (franchiseeId ? '&franchisee=' + franchiseeId : '');
    app.turnToPage(pagePath);
  },
  goodsCoverOnload: function (e) {
    var originalWidth = e.detail.width,
        originalHeight = e.detail.height;

    //获取图片的原始长宽
    var windowWidth = 0;
    var imageWidth = 0, imageHeight = 0;

    var res = app.getSystemInfoData();

    windowWidth = res.windowWidth;
    imageWidth = windowWidth;
    imageHeight = imageWidth * originalHeight / originalWidth;
    this.setData({
      goodsCoverWidth: imageWidth,
      goodsCoverHeight: imageHeight
    });
  },
  modifyGoodsDetail: function (res) {
    var pages = getCurrentPages(),
      _this = pages[pages.length - 1],
      goods = res.data[0].form_data,
      description = goods.description,
      goodsModel = [],
      selectModels = [],
      modelStrs = {},
      price = 0,
      discountStr = '',
      allStock = 0,
      selectStock, selectPrice, selectModelId, matchResult, selectGroupPrice, selectGroupLeaderPrice, selectGroupNum, selectImgurl = '',
      i, j;

    WxParse.wxParse('wxParseDescription', 'html', description, _this, 10);

    if (goods.model_items.length) {
      var items = goods.model_items;
      for (i = 0, j = items.length; i < j; i++) {
        price = Number(items[i].price);
        goods.highPrice = goods.highPrice > price ? goods.highPrice : price;
        goods.lowPrice = goods.lowPrice < price ? goods.lowPrice : price;
        allStock += Number(items[i].stock);
        if (i == 0) {
          selectPrice = price;
          selectGroupNum = Number(items[i].num_of_people);
          selectGroupPrice = Number(items[i].group_buy_normal_price);
          selectGroupLeaderPrice = Number(items[i].group_buy_leader_price);
          selectStock = items[0].stock;
          selectModelId = items[0].id;
          selectImgurl = items[i].img_url;
        }
      }
      allStock = allStock/goods.group_buy_info.num_of_people_list.length;
    } else {
      selectPrice = goods.price;
      selectStock = goods.stock;
      selectImgurl = goods.cover;
    }
    for (var key in goods.model) {
      if (key) {
        var model = goods.model[key];
        goodsModel.push(model);
        modelStrs[model.id] = model.subModelName.join('、');
        selectModels.push(model.subModelId[0]);
      }
    }
    goods.model = goodsModel;
    if (Number(goods.max_can_use_integral) != 0) {
      discountStr = '（积分可抵扣' + (Number(goods.max_can_use_integral) / 100) + '元）';
    }
    _this.setData({
      goodsInfo: goods,
      modelStrs: modelStrs,
      'selectModelInfo.models': selectModels,
      'selectModelInfo.stock': selectStock,
      'selectModelInfo.price': selectPrice,
      'selectModelInfo.groupNum': selectGroupNum,
      'selectModelInfo.groupPrice': selectGroupPrice,
      'selectModelInfo.groupLeaderPrice': selectGroupLeaderPrice,
      'selectModelInfo.modelId': selectModelId || '',
      'selectModelInfo.imgurl': selectImgurl || '',
      allStock: allStock,
      priceDiscountStr: discountStr,
    })
    _this.getAssessList();
  },
  getAssessList: function () {
    var that = this;
    app.getAssessList({
      method: 'post',
      header: {
        'content-type': 'application/x-www-form-urlencoded;'
      },
      data: {
        goods_id: that.data.goodsId,
        idx_arr: {
          idx: 'level',
          idx_value: 0
        },
        page: 1,
        page_size: 20,
        sub_shop_app_id: this.data.franchiseeId
      },
      success: function (res) {
        var commentExample = res.data[0];
        // if (commentExample) {
        //   commentExample.add_time = util.formatTime(new Date(commentExample.add_time * 1000));
        // }
        that.setData({
          commentNums: res.num,
          commentExample: commentExample || ''
        })
      }
    });
  },
  showGroupBuy: function () {
    this.setData({
      addToGroupBuyCart: false,
      ifOpenNewGroup: false,
      isParticipate: false
    })
  },
  //去参团的方法
  participateGroup: function (e) {
    this.setData({
      addToGroupBuyCart: false,
      ifOpenNewGroup: false,
      isParticipate: true,
      'selectModelInfo.groupNum': e.currentTarget.dataset.num,
      teamToken: e.currentTarget.dataset.token
    })
    this.resetSelectCountPrice();
  },
  showBuyDirectly: function () {
    this.setData({
      addToShoppingCartHidden: false,
      ifAddToShoppingCart: false
    })
  },
  showAddToShoppingCart: function () {
    this.setData({
      addToShoppingCartHidden: false,
      ifAddToShoppingCart: true
    })
  },
  hideGroupBuyCart: function () {
    this.setData({
      addToGroupBuyCart: true
    })
  },
  hiddeAddToShoppingCart: function () {
    this.setData({
      addToShoppingCartHidden: true
    })
  },
  selectSubModel: function (e) {
    var dataset = e.target.dataset,
      modelIndex = dataset.modelIndex,
      submodelIndex = dataset.submodelIndex,
      data = {};

    data['selectModelInfo.models[' + modelIndex + ']'] = this.data.goodsInfo.model[modelIndex].subModelId[submodelIndex];
    this.setData(data);
    this.resetSelectCountPrice();
  },
  resetSelectCountPrice: function () {
    var selectModelIds = this.data.selectModelInfo.models.join(','),
      modelItems = this.data.goodsInfo.model_items,
      data = {};

    for (var i = modelItems.length - 1; i >= 0; i--) {
      if(modelItems[i].model){
        if (modelItems[i].model == selectModelIds && modelItems[i].num_of_people == this.data.selectModelInfo.groupNum) {
          data['selectModelInfo.stock'] = modelItems[i].stock;
          data['selectModelInfo.price'] = modelItems[i].price;
          data['selectModelInfo.groupPrice'] = modelItems[i].group_buy_normal_price;
          data['selectModelInfo.groupLeaderPrice'] = modelItems[i].group_buy_leader_price;
          data['selectModelInfo.modelId'] = modelItems[i].id;
          data['selectModelInfo.imgurl'] = modelItems[i].img_url;
          break;
        }
      }else{
        if (modelItems[i].num_of_people == this.data.selectModelInfo.groupNum) {
          data['selectModelInfo.stock'] = modelItems[i].stock;
          data['selectModelInfo.price'] = modelItems[i].price;
          data['selectModelInfo.groupPrice'] = modelItems[i].group_buy_normal_price;
          data['selectModelInfo.groupLeaderPrice'] = modelItems[i].group_buy_leader_price;
          data['selectModelInfo.modelId'] = modelItems[i].id;
          data['selectModelInfo.imgurl'] = modelItems[i].img_url;
          break;
        }
      }
    }
    this.setData(data);
  },
  clickMinusButton: function (e) {
    var count = this.data.selectModelInfo.buyCount;

    if (count <= 1) {
      return;
    }
    this.setData({
      'selectModelInfo.buyCount': count - 1
    });
  },
  clickGroupMinusButton: function (e) {
    var count = this.data.selectModelInfo.groupBuyCount;

    if (count <= 1) {
      return;
    }
    this.setData({
      'selectModelInfo.groupBuyCount': count - 1
    });
  },
  clickPlusButton: function (e) {
    var selectModelInfo = this.data.selectModelInfo,
      count = selectModelInfo.buyCount,
      stock = selectModelInfo.stock,
      max = this.data.goodsInfo.group_buy_info.user_limit_buy;

    if (count >= stock) {
      return;
    }
    this.setData({
      'selectModelInfo.buyCount': count + 1
    });
  },
  clickGroupPlusButton: function (e) {
    var selectModelInfo = this.data.selectModelInfo,
      count = selectModelInfo.groupBuyCount,
      stock = selectModelInfo.stock,
      max = this.data.goodsInfo.group_buy_info.user_limit_buy;

    if (count >= stock || count >= max) {
      return;
    }
    this.setData({
      'selectModelInfo.groupBuyCount': count + 1
    });
  },
  sureAddToShoppingCart: function () {
    var that = this,
      param = {
        goods_id: this.data.goodsId,
        model_id: this.data.selectModelInfo.modelId || '',
        num: this.data.selectModelInfo.buyCount,
        sub_shop_app_id: this.data.franchiseeId || ''
      };

    app.sendRequest({
      url: '/index.php?r=AppShop/addCart',
      data: param,
      success: function (res) {
        app.showToast({
          title: '添加成功',
          icon: 'success',
          duration: 1500
        });

        setTimeout(function () {
          app.hideToast();
          that.hiddeAddToShoppingCart();
        }, 500);
      }
    })
  },
  buyDirectlyNextStep: function (e) {
    var franchiseeId = this.data.franchiseeId,
      param = {
        goods_id: this.data.goodsId,
        model_id: this.data.selectModelInfo.modelId || '',
        num: this.data.selectModelInfo.buyCount,
        sub_shop_app_id: franchiseeId || ''
      };

    app.sendRequest({
      url: '/index.php?r=AppShop/addCart',
      data: param,
      success: function (res) {
        var cart_arr = [res.data],
          pagePath = '/eCommerce/pages/previewGoodsOrder/previewGoodsOrder?cart_arr=' + encodeURIComponent(cart_arr);

        franchiseeId && (pagePath += '&franchisee=' + franchiseeId);
        app.turnToPage(pagePath);
      }
    })
  },
  groupBuyDirectlyNextStep: function (e) {
    var franchiseeId = this.data.franchiseeId,
      _this = this,
      param = {
        goods_id: this.data.goodsId,
        model_id: this.data.selectModelInfo.modelId || '',
        num: this.data.selectModelInfo.groupBuyCount,
        sub_shop_app_id: franchiseeId || '',
        is_group_buy: 1,
        num_of_group_buy_people: this.data.selectModelInfo.groupNum || '',
        team_token: ''
      };

    app.sendRequest({
      url: '/index.php?r=AppShop/addCart',
      data: param,
      success: function (res) {
        var cart_arr = [res.data],
          pagePath = '/eCommerce/pages/previewGoodsOrder/previewGoodsOrder?cart_arr=' + encodeURIComponent(cart_arr) + '&limit_buy=' + _this.data.goodsInfo.group_buy_info.user_limit_buy + '&is_group=true' + '&group_buy_people=' + _this.data.selectModelInfo.groupNum;

        franchiseeId && (pagePath += '&franchisee=' + franchiseeId);
        app.turnToPage(pagePath);
      }
    })
  },
  participateGroupBuy: function (e) {
    var franchiseeId = this.data.franchiseeId,
      _this = this,
      param = {
        goods_id: this.data.goodsId,
        model_id: this.data.selectModelInfo.modelId || '',
        num: this.data.selectModelInfo.groupBuyCount,
        sub_shop_app_id: franchiseeId || '',
        is_group_buy: 1,
        num_of_group_buy_people: this.data.selectModelInfo.groupNum || '',
        team_token: this.data.teamToken
      };

    app.sendRequest({
      url: '/index.php?r=AppShop/addCart',
      data: param,
      success: function (res) {
        var cart_arr = [res.data],
          pagePath = '/eCommerce/pages/previewGoodsOrder/previewGoodsOrder?cart_arr=' + encodeURIComponent(cart_arr) + '&limit_buy=' + _this.data.goodsInfo.group_buy_info.user_limit_buy + '&is_group=true'+ '&team_token=' + _this.data.teamToken + '&group_buy_people=' + _this.data.selectModelInfo.groupNum;
        franchiseeId && (pagePath += '&franchisee=' + franchiseeId);
        app.turnToPage(pagePath);
      }
    })
  },
  makeAppointment: function () {
    var franchiseeId = this.data.franchiseeId,
        pagePath = '/eCommerce/pages/makeAppointment/makeAppointment?detail=' + this.data.goodsId + (franchiseeId ? '&franchisee=' + franchiseeId : '');
    app.turnToPage(pagePath);
  },
  inputBuyCount: function (e) {
    var count = e.detail.value;
    this.setData({
      'selectModelInfo.buyCount': +count
    });
  },
  showShareMenu: function () {
    app.showShareMenu();
  },
  turnToGroupRules: function () {
    app.turnToPage("/eCommerce/pages/groupRules/groupRules");
  },
  selectGroupNum: function (e) {
    //console.log(e.currentTarget.dataset.num);
    this.setData({ 'selectModelInfo.groupNum': e.currentTarget.dataset.num });
    this.resetSelectCountPrice();
  },
  showAll: function (e) {
    let _this = this;
    this.setData({ ifAllGroup: !_this.data.ifAllGroup });
  },

  //计算倒计时时间
  parseArr: function (time) {
    let arr = [];
    let now = (new Date()).valueOf();

    arr = time.map(function (el) {
      return el.expired_time * 1000 - now;
    })
    this.data.arr = arr;
  },
  //倒计时方法
  countDown: function () {
    let _this = this;
    let arr = _this.data.arr;
    let t = setInterval(function () {
      arr = arr.map(function (el) {
        return el - 500;
      })
      let prettyTime = arr.map(function (el) {
        if (el >= 0) {
          return _this.date_format(el);
        } else {
          return '已截止';
        }
      })
      _this.setData({ clock: prettyTime });
      //console.log(arr);
    }, 500);
    return {
      clear: function () {
        clearInterval(t);
      }
    }
  },

  // 时间格式化输出，如03:25:19 86。每500ms都会调用一次
  date_format: function (micro_second) {
    // 秒数
    let second = Math.floor(micro_second / 1000);
    // 小时位
    let hr = Math.floor(second / 3600);
    // 分钟位
    let min = this.fill_zero_prefix(Math.floor((second - hr * 3600) / 60));
    // 秒位
    let sec = this.fill_zero_prefix((second - hr * 3600 - min * 60));// equal to => var sec = second % 60;

    return hr + ":" + min + ":" + sec;
  },

  // 位数不足补零
  fill_zero_prefix: function (num) {
    return num < 10 ? "0" + num : num
  }
})
