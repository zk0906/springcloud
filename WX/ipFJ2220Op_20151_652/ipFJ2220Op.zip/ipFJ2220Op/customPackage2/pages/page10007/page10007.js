var app      = getApp();

var pageData = {
  data: {"picture1":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:112.5rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65917166e8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"6.68","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_249092385757","page_form":"","compId":"picture1"},"text2":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;opacity:1;text-align:left;","content":"      \u5bb6\u88c5\u6c34\u7535\uff0c\u662f\u4e00\u9879\u6210\u5c31\u5343\u5bb6\u4e07\u6237\u5e78\u798f\u7684\u4e8b\u4e1a\u3002\u6211\u4eec\u575a\u51b3\u4e00\u4e1d\u4e0d\u82df\u5bf9\u5f85\u6bcf\u4e00\u4ef6\u4f5c\u54c1\uff0c\u6bcf\u4e00\u9053\u5de5\u827a\u3001\u6bcf\u4e00\u4e2a\u5de5\u5e8f\uff0c\u6211\u4eec\u7686\u4e13\u6ce8\u7ec6\u8282\uff0c\u8ffd\u6c42\u6781\u81f4\uff0c\u7cbe\u76ca\u6c42\u7cbe\u529b\u7b51\u5b8c\u7f8e\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_870673216700","page_form":"","compId":"text2","markColor":"","mode":0},"picture3":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:35.15625rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65b6ef2419.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"9.58","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_96463205993","page_form":"","compId":"picture3"},"picture4":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65c369093d.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"11.04","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_977314362612","page_form":"","compId":"picture4"},"picture5":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:77.34375rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65d109d2a9.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"11.38","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_827937813920","page_form":"","compId":"picture5"},"picture6":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:140.625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65d73dedc8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"5.38","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_122133208288","page_form":"","compId":"picture6"},"picture7":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:796.875rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65d8bde99d.jpg","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.88","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_457675633222","page_form":"","compId":"picture7"},"picture8":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:58.59375rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca65f90c3cb4.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_844304841785","page_form":"","compId":"picture8"},"text9":{"type":"text","style":"background-color:rgba(0, 0, 0, 0);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(0, 0, 0);font-size:28.125rpx;height:58.59375rpx;line-height:58.59375rpx;margin-left:auto;margin-right:auto;margin-top:0;opacity:1;text-align:left;","content":"\u603b\u7ed3\u591a\u5e74\u7684\u6c34\u7535\u5de5\u5730\u5b9e\u64cd\u7ecf\u9a8c\uff0c\u6c72\u53d6\u5fb7\u827a\u5de5\u827a\u7cbe\u9ad3\uff0c\u575a\u5b88\u7528\u6c34\u7528\u7535\u957f\u5c45\u4e45\u5b89\u539f\u5219\uff0c\u5168\u9762\u4fdd\u969c\u5bb6\u5c45\u6c34\u7535\u5b89\u5168\u3001\u6301\u4e45\u3001\u8010\u7528\u3002","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0","textColor":"rgb(0, 0, 0)","textStyle":false,"textX":"0","textY":"0","textR":"5","isWordWrap":0,"dataObject":false,"word-wrap":2,"phoneNumberSource":"static","phoneDisplayContent":"static","name":"\u6587\u672c","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_536577231461","page_form":"","compId":"text9","markColor":"","mode":0},"picture10":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bab813e9.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.67","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_479109998567","page_form":"","compId":"picture10"},"picture11":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66ba724ec1.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.67","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_639607824514","page_form":"","compId":"picture11"},"picture12":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66ba4afc34.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.67","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_792720088714","page_form":"","compId":"picture12"},"picture13":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66ba22af04.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.67","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_52595542810","page_form":"","compId":"picture13"},"picture14":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bcbe2bc8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.66","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_731741486485","page_form":"","compId":"picture14"},"picture15":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:468.75rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66b9f586c8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.67","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_521886015194","page_form":"","compId":"picture15"},"picture16":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:58.59375rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca661d0b4ce0.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_810543530488","page_form":"","compId":"picture16"},"picture17":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:726.5625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bc927adf.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.00","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_181238708196","page_form":"","compId":"picture17"},"picture18":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:726.5625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bc695888.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.00","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_618221704341","page_form":"","compId":"picture18"},"picture19":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:726.5625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bc3c96a8.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.00","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_347962845674","page_form":"","compId":"picture19"},"picture20":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:726.5625rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bc107235.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.00","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_811240796456","page_form":"","compId":"picture20"},"picture21":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:58.59375rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca662b38e727.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_291573269347","page_form":"","compId":"picture21"},"picture22":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:445.3125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bbb8cf93.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.73","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_368620305300","page_form":"","compId":"picture22"},"picture23":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:445.3125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bb94b6d2.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.74","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_823613337326","page_form":"","compId":"picture23"},"picture24":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:445.3125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bbec9186.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.74","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_139693580231","page_form":"","compId":"picture24"},"picture25":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:445.3125rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bb6a7bd5.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"1.74","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_971480153538","page_form":"","compId":"picture25"},"picture26":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:93.75rpx;margin-left:auto;margin-right:auto;margin-top:58.59375rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca663f341c26.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"8.50","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_274817907843","page_form":"","compId":"picture26"},"picture27":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:750rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bcf17daf.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.85","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_646271122435","page_form":"","compId":"picture27"},"picture28":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:750rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bb3e2c49.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.85","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_587282671160","page_form":"","compId":"picture28"},"picture29":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:750rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bb0f194e.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.85","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_52904448397","page_form":"","compId":"picture29"},"picture30":{"type":"picture","style":"opacity:1;background-color:transparent;border-color:rgb(34, 34, 34);border-radius:0rpx;border-style:none;border-width:0rpx;height:750rpx;margin-left:auto;margin-right:auto;margin-top:11.71875rpx;","content":"https:\/\/img.zhichiwangluo.com\/zcimgdir\/album\/file_5ca66bade70d9.png","customFeature":{"boxShadow":"('#000','0','0','5')","boxColor":"#000","boxX":"0","boxY":"0","boxR":"5","dataObject":false,"phoneNumberSource":"static","phoneDisplayContent":"static","isAuto":false,"photoRatio":"0.85","name":"\u56fe\u7247","backgroundType":false,"isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_458949915452","page_form":"","compId":"picture30"},"breakline31":{"type":"breakline","style":"border-width:117.1875rpx;border-bottom-style:solid;margin-top:23.4375rpx;margin-left:0;margin-right:auto;width:750rpx;border-bottom-color:rgba(0, 0, 0, 0);","content":"<div><\/div>","customFeature":{"name":"\u5206\u5272\u7ebf","isLockWidget":false},"animations":[],"hidden":false,"id":"zhichi_266967205624","page_form":"","compId":"breakline31"},"has_tabbar":0,"page_hidden":true,"page_form":"store_list","top_nav":{"navigationBarBackgroundColor":"#fff","navigationBarTextStyle":"black","navigationBarTitleText":"\u6c34\u7535\u5de5\u827a"},"dataId":""},
    need_login: false,
      bind_phone: false,
    page_router: 'page10007',
    page_form: 'none',
      dataId: '',
      list_compids_params: [],
      user_center_compids_params: [],
      goods_compids_params: [],
  prevPage:0,
      tostoreComps: [],
      carouselGroupidsParams: [],
      relobj_auto: [],
      bbsCompIds: [],
      dynamicVesselComps: [],
      communityComps: [],
      franchiseeComps: [],
      cityLocationComps: [],
      seckillOnLoadCompidParam: [],
      dynamicClassifyGroupidsParams: [],
      newClassifyGroupidsParams: [],
      videoListComps: [],
      videoProjectComps: [],
      newsComps: [],
      popupWindowComps: [],
        formVesselComps: [],
      searchComponentParam: [],
      topicComps: [],
      topicClassifyComps: [],
      topicSortComps: [],
      rowNumComps: [],
      sidebarComps: [],
      slidePanelComps: [],
      newCountComps: [],
      exchangeCouponComps: [],
      communityGroupComps: [],
      groupBuyStatusComps: [],
      groupBuyListComps: [],
      timelineComps: [],
      signInComps: [],
    returnToVersionFlag: true,
  requesting: false,
  requestNum: 1,
  modelChoose: [],
  modelChooseId: '',
  modelChooseName: [],
  onLoad: function (e) {
    if (e.statisticsType == 11) {
      delete e.statisticsType
      delete e.needStatistics
    }
    if (e.franchisee) {
      this.franchiseeId = e.franchisee;
      this.setData({
        franchiseeInfo: {
          id: e.franchisee,
          mode: e.fmode || ''
        }
      });
    }
    app.onPageLoad(e);
    app.isNeedRewardModal();
  },
  dataInitial: function () {
    app.pageDataInitial();
    if (this.page_router === 'userCenterComponentPage'){
      this.getAppECStoreConfig();
    }
  },
  onPageScroll: function(e) {
    app.onPageScroll(e);
  },
  onShareAppMessage: function (e) {
    if (e.from == 'button') {
      if (e.target.dataset && e.target.dataset.from == 'topicButton') {
        let franchiseeId = app.getPageFranchiseeId();
        let chainParam = franchiseeId ? '&franchisee=' + franchiseeId : '';
        return app.shareAppMessage({
          path: '/informationManagement/pages/communityDetail/communityDetail?detail=' + e.target.dataset.id + chainParam,
          desc: e.target.dataset.desc,
          success: function(addTime) {
            app.getIntegralLog(addTime);
            app.CountSpreadCount(e.target.dataset.id);
          }
        });
      }
    };
    return app.onPageShareAppMessage(e, app.getIntegralLog);
  },
  onShow: function () {
    app.onPageShow();
  },
  onHide: function () {
    app.onPageHide();
  },
  reachBottomFuc: [],
  onReachBottom: function () {
    app.onPageReachBottom( this.reachBottomFuc );
  },
  onUnload: function () {
    app.onPageUnload(this);
  },
  slidePanelStart: function (e) {
    app.slidePanelStart(e);
  },
  slidePanelEnd: function (e) {
    app.slidePanelEnd(e);
  },
  onPullDownRefresh : function(){
    app.onPagePullDownRefresh();
  },
  tapPrevewPictureHandler: function (e) {
    app.tapPrevewPictureHandler(e);
  },
  pageScrollFunc: function (e) {
    app.pageScrollFunc(e);
  },
  dynamicVesselScrollFunc: function (e) {
    app.dynamicVesselScrollFunc(e);
  },
  goodsScrollFunc: function (e) {
    app.goodsScrollFunc(e);
  },
  changeCount: function (e) {
    app.changeCount(e);
  },
  tapMapDetail: function (e) {
    app.tapMapDetail(e);
  },
  listVesselTurnToPage: function (e) {
    app.listVesselTurnToPage(e);
  },
  dynamicVesselTurnToPage: function (e) {
    app.dynamicVesselTurnToPage(e);
  },
  userCenterTurnToPage: function (e) {
    app.userCenterTurnToPage(e);
  },
  turnToGoodsDetail: function (e) {
    app.turnToGoodsDetail(e);
  },
  turnToSeckillDetail: function (e) {
    app.turnToSeckillDetail(e);
  },
  sortListFunc: function (e) {
    app.sortListFunc(e);
  },
  selectLocal: function (e) {
    app.selectLocal(e);
  },
  cancelCity: function (e) {
    app.cancelCity(e);
  },
  bindCityChange: function (e) {
    app.bindCityChange(e);
  },
  submitCity: function (e) {
    app.submitCity(e);
  },
  callPhone: function (e) {
    app.callPhone(e);
  },
  tapVideoPlayHandler: function(e){
    app.tapVideoPlayHandler(e);
  },
  tapToPluginHandler: function (e) {
    app.tapToPluginHandler(e);
  },
  tapRefreshListHandler: function (e) {
    app.tapRefreshListHandler(e);
  },
  turnToCommunityPage: function (e) {
    app.turnToCommunityPage(e);
  },
  tapToTransferPageHandler: function () {
    app.tapToTransferPageHandler();
  },
  showGoodsShoppingcart: function(e){
    app.showGoodsShoppingcart(e);
  },
  showAddShoppingcart: function (e) {
    app.showAddShoppingcart(e);
  },
  hideAddShoppingcart: function () {
    app.hideAddShoppingcart();
  },
  selectGoodsSubModel: function (e) {
    app.selectGoodsSubModel(e);
  },
  resetSelectCountPrice: function () {
    app.resetSelectCountPrice();
  },
  clickTostoreMinusButton: function (e) {
    app.clickTostoreMinusButton(e);
  },
  clickTostorePlusButton: function (e) {
    app.clickTostorePlusButton(e);
  },
  readyToPay: function () {
    app.readyToTostorePay();
  },
  getValidateTostore: function () {
    app.getValidateTostore();
  },
  goToShoppingCart: function () {
    app.goToShoppingCart();
  },
  stopPropagation: function () {
  },
  turnToSearchPage:function (e) {
    app.turnToSearchPage(e);
  },
  previewImage: function (e) {
    var dataset = e.currentTarget.dataset;
    app.previewImage({
      current : dataset.src,
      urls: dataset.imgarr || [dataset.src],
    });
  },
  suspensionTurnToPage: function (e) {
    app.suspensionTurnToPage(e);
  },
  keywordList:{},
  bindSearchTextChange: function (e) {
    this.keywordList[e.currentTarget.dataset.compid] = e.detail.value;
  },
  // 文字组件跳到地图
  textToMap: function(e) {
    app.textToMap(e);
  },
  tapDynamicClassifyFunc: function(e){
    app.tapDynamicClassifyFunc(e);
  },
  // 跳转到资讯详情
  turnToNewsDetail: function (e) {
    app.turnToNewsDetail(e)
  },
  //切换资讯分类
  getNewsCateList: function (e) {
    app.getNewsCateList(e);
  },
  //话题组件
  topicEleScrollFunc: function (e) {
    app.topicEleScrollFunc(e);
  },
  switchTopiclistOrderBy: function (e) {
    app.switchTopiclistOrderBy(e);
  },
  switchTopicCategory: function (e) {
    app.switchTopicCategory(e);
  },
  turnToTopicDetail: function (e) {
    app.turnToTopicDetail(e);
  },
  pageBackTopAct: function (e) {
    app.pageBackTopAct(e);
  },
  turnToTopicPublish: function (e) {
    app.turnToTopicPublish(e);
  },
  showTopicCommentBox: function (e) {
    app.showTopicCommentBox(e);
  },
  showTopicPhoneModal: function (e) {
    app.showTopicPhoneModal(e);
  },
  topicMakePhoneCall: function (e) {
    app.topicMakePhoneCall(e);
  },
  showTopicReplyComment: function (e) {
    app.showTopicReplyComment(e);
  },
  topicCommentReplyInput: function (e) {
    app.topicCommentReplyInput(e);
  },
  topicReplycommentSubmit: function (e) {
    app.topicReplycommentSubmit(e);
  },
  topicPerformLikeAct: function (e) {
    app.topicPerformLikeAct(e);
  },
  topicImgLoad: function (e) {
    app.topicImgLoad(e);
  },
  topicCommentReplyfocus:function (e) {
    app.topicCommentReplyfocus(e);
  },
  topicCommentReplyblur:function (e) {
    app.topicCommentReplyblur(e);
  },

  // 筛选组件 综合排序tab = 0
  sortByDefault: function (e) {
    app.sortByDefault(e);
  },
  // 筛选组件 按销量排序 tab = 1
  sortBySales: function (e) {
    app.sortBySales(e);
  },
  // 筛选组件 按价格排序 tab = 2
  sortByPrice: function (e) {
    app.sortByPrice(e);
  },
  // 筛选组件 按取货排序 tab = 3
  pickUpStyle: function (e) {
    app.pickUpStyle(e);
  },
  hideFilterPickUpBox: function (e){
    app.hideFilterPickUpBox(e);
  },
  selectPickUp: function(e){
    app.selectPickUp(e);
  },
  surePickBtn: function(e){
    app.surePickBtn(e);
  },
  resetPickBtn: function(e){
    app.resetPickBtn(e);
  },
  // 筛选组件 展示侧边筛选
  filterList: function(e){
    app.filterList(e);
  },
  // 筛选侧栏确定
  filterConfirm: function(e){
    app.filterConfirm(e);
  },
  // 动画结束回调函数
  animationEnd: function(e){
    app.animationEnd(e);
  },
  //排号
  showTakeNumberWindow: function(e){
    app.showTakeNumberWindow(e);
  },
  hideTakeNumberWindow: function(e){
    app.hideTakeNumberWindow(e);
  },
  goToPreviewRowNumberOrder: function(e){
    app.goToPreviewRowNumberOrder(e);
  },
  selectRowNumberType: function(e){
    app.selectRowNumberType(e);
  },
  sureTakeNumber: function(e){
    app.sureTakeNumber(e);
  },
  goToCheckRowNunberDetail: function(e){
    app.goToCheckRowNunberDetail(e);
  },
  cancelCheckRowNunber: function(e){
    app.cancelCheckRowNunber(e);
  },
  rowNumberRefresh: function(e){
    app.rowNumberRefresh(e);
  },
  showCancelWindow: function (e) {
    app.showCancelWindow(e)
  },
  hideCancelWindow: function (e) {
    app.hideCancelWindow(e)
  },
  tapEventCommonHandler: function(e){
    app.tapEventCommonHandler(e);
  },
  getCarouselData: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app._initialCarouselData(this, compid );
  },
  getNewsList: function(e) {
    let compid = e.currentTarget.dataset.compid;
    app.getNewsList({ compid: compid });
  },
  getCommunityList: function (e) {
    let compid = e.currentTarget.dataset.compid;
    app.initialCommunityList(compid);
  },
  getexchangeCoupon: function(e) {
    app.getexchangeCoupon(e);
  },
  turnToexchangeCouponDetail: function (e) {
    app.turnToexchangeCouponDetail(e);
  },
  exchangeCouponScrollFunc: function (e) {
    app.exchangeCouponScrollFunc(e);
  },
  vipCardTurnToPage: function (e) {
    app.vipCardTurnToPage(e);
  },
  showQRRemark: function (e) {
    app.showQRRemark(e);
  },
  tapDynamicShowAllClassify: function (e) {
    app.tapDynamicShowAllClassify(e);
  },
  dynamicSubClassifyAreaScrollEvent: function (e) {
    app.dynamicSubClassifyAreaScrollEvent(e);
  },
  slidePanelScrollEvent: function (e) {
    app.slidePanelScrollEvent(e);
  },
  unfoldSus: function(e) {
    let compId = e.currentTarget.dataset.compid;
    let tapType = e.currentTarget.dataset.taptype;
    app.newSuspension_unfoldSus(compId,tapType);
  },
  newCountTapEvent: function (e) {
    app.newCountTapEvent(e);
  },
  chengeCommunityGroup(e) {
    app.chengeCommunityGroup(e);
  },
  toCommunityGroup(e) {
    app.toCommunityGroup(e);
  },
  communityGroupScrollFunc(e) {
    app.communityGroupScrollFunc(e);
  },
  getAppECStoreConfig: function () {
    app.getAppECStoreConfig((res) => {
      this.setData({
        storeStyle: res.color_config
      })
    });
  },

  };
Page(pageData);
